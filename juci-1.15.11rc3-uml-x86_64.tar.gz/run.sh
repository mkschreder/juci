#!/bin/bash

./openwrt-uml-vmlinux ubd0=openwrt-uml-ext4.img eth0=tuntap,tap0,,192.168.10.10
